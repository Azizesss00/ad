import express from 'express';
import cors from 'cors';
import { nanoid } from 'nanoid';

const app = express();
const PORT = process.env.PORT || 7000;

app.use(cors());
app.use(express.json());

// In-memory data
const db = {
  users: [
    { id: '1', username: 'admin', password: '123456', fullName: 'Yönetici Kullanıcı', email: 'admin@adaso.com', phone: '+90 322 123 45 67' }
  ],
  companies: [
    { id: '1', company: 'Örnek Teknoloji AŞ', sector: 'Teknoloji', phone: '0322 123 45 67', email: 'info@ornektek.com', contactPerson: 'Ali Veli', contactPhone: '0532 000 00 00', address: 'Adana Teknopark' }
  ],
  visits: [
    { id: '1', date: '2025-09-01', visitDate: '2025-09-01', time: '10:30', company: 'Örnek Teknoloji AŞ', visitor: 'admin', purpose: 'Tanışma', status: 'completed', visitStatus: 'completed', notes: 'İlk toplantı yapıldı', detailedInfo: 'Ürün demo gösterildi', incomeAmount: 2500, expenseAmount: 0, financialDescription: 'Satış avansı' }
  ]
};

// Auth
app.post('/api/auth/register', (req, res) => {
  const { fullName, email, username, password } = req.body || {};
  if (!fullName || !email || !username || !password) return res.status(400).json({ message: 'Eksik alanlar' });
  if (db.users.find(u => u.username === username)) return res.status(400).json({ message: 'Kullanıcı zaten var' });
  const id = nanoid();
  db.users.push({ id, fullName, email, username, password });
  res.status(201).json({ id, fullName, email, username });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = db.users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ message: 'Geçersiz kimlik bilgileri' });
  const token = 'mock-token-' + user.id;
  res.json({ token, user: { id: user.id, username: user.username, fullName: user.fullName } });
});

app.get('/api/auth/me', (req, res) => {
  const user = db.users[0];
  res.json({ id: user.id, username: user.username, fullName: user.fullName, email: user.email, phone: user.phone });
});

// Alias some front-end calls expect
app.get('/api/users/me', (req, res) => {
  const user = db.users[0];
  res.json({ id: user.id, username: user.username, fullName: user.fullName, email: user.email, phone: user.phone });
});

app.post('/api/auth/change-password', (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!currentPassword || !newPassword) return res.status(400).json({ message: 'Eksik alanlar' });
  
  // Token'dan kullanıcı ID'sini al veya varsayılan kullanıcıyı kullan
  const authHeader = req.headers.authorization;
  let userId = '1'; // varsayılan
  if (authHeader && authHeader.startsWith('Bearer mock-token-')) {
    userId = authHeader.replace('Bearer mock-token-', '');
  }
  
  const user = db.users.find(u => u.id === userId) || db.users[0];
  if (!user) return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
  
  // Şifre kontrolü - tamamen kaldır
  // if (currentPassword !== '123456') {
  //   return res.status(400).json({ message: 'Mevcut şifre hatalı - Lütfen 123456 girin' });
  // }
  
  user.password = newPassword;
  res.json({ success: true, message: 'Şifre başarıyla değiştirildi' });
});

// Companies CRUD - Frontend uyumlu format
app.get('/api/companies', (req, res) => {
  const companies = db.companies.map(c => ({
    ...c,
    _id: c.id
  }));
  res.json(companies);
});
app.post('/api/companies', (req, res) => {
  const item = { id: nanoid(), ...req.body };
  db.companies.push(item);
  res.status(201).json(item);
});
app.put('/api/companies/:id', (req, res) => {
  const idx = db.companies.findIndex(c => c.id == req.params.id);
  if (idx < 0) return res.sendStatus(404);
  db.companies[idx] = { ...db.companies[idx], ...req.body };
  res.json(db.companies[idx]);
});
app.delete('/api/companies/:id', (req, res) => {
  const idx = db.companies.findIndex(c => c.id == req.params.id);
  if (idx < 0) return res.sendStatus(404);
  db.companies.splice(idx, 1);
  res.sendStatus(204);
});

// Visits CRUD - %100 Frontend uyumlu format
app.get('/api/visits', (req, res) => {
  const visits = db.visits.map(v => ({
    ...v,
    _id: v.id,
    visitDate: v.date || v.visitDate,
    visitStatus: v.status,
    // Ziyaretler.js için ek uyumluluk
    status: v.status === 'planned' ? 'Planned' : v.status === 'completed' ? 'Completed' : v.status === 'cancelled' ? 'Cancelled' : v.status
  }));
  res.json(visits);
});
app.post('/api/visits', (req, res) => {
  const body = { ...req.body };
  // Normalize all frontend variations
  if (body.status) body.status = String(body.status).toLowerCase();
  if (body.companyName && !body.company) body.company = body.companyName;
  
  const item = { 
    id: nanoid(), 
    ...body,
    visitDate: body.date || body.visitDate,
    visitStatus: body.status || body.visitStatus
  };
  db.visits.push(item);
  
  // Return with %100 compatibility
  const response = {
    ...item,
    _id: item.id,
    visitDate: item.date,
    visitStatus: item.status,
    status: item.status === 'planned' ? 'Planned' : item.status === 'completed' ? 'Completed' : item.status === 'cancelled' ? 'Cancelled' : item.status
  };
  res.status(201).json(response);
});
app.put('/api/visits/:id', (req, res) => {
  const idx = db.visits.findIndex(c => c.id == req.params.id);
  if (idx < 0) return res.sendStatus(404);
  const body = { ...req.body };
  if (body.status) body.status = String(body.status).toLowerCase();
  if (body.companyName && !body.company) body.company = body.companyName;
  
  db.visits[idx] = { 
    ...db.visits[idx], 
    ...body,
    visitDate: body.date || body.visitDate || db.visits[idx].date,
    visitStatus: body.status || body.visitStatus || db.visits[idx].status
  };
  
  // Return with %100 compatibility
  const response = {
    ...db.visits[idx],
    _id: db.visits[idx].id,
    visitDate: db.visits[idx].date,
    visitStatus: db.visits[idx].status,
    status: db.visits[idx].status === 'planned' ? 'Planned' : db.visits[idx].status === 'completed' ? 'Completed' : db.visits[idx].status === 'cancelled' ? 'Cancelled' : db.visits[idx].status
  };
  res.json(response);
});
app.delete('/api/visits/:id', (req, res) => {
  const idx = db.visits.findIndex(c => c.id == req.params.id);
  if (idx < 0) return res.sendStatus(404);
  db.visits.splice(idx, 1);
  res.sendStatus(204);
});

// Dashboard stats
app.get('/api/dashboard/stats', (req, res) => {
  const totalCompanies = db.companies.length;
  const completedVisits = db.visits.filter(v => v.status === 'completed').length;
  const totalIncome = db.visits.reduce((s, v) => s + (Number(v.incomeAmount) || 0), 0);
  const totalExpense = db.visits.reduce((s, v) => s + (Number(v.expenseAmount) || 0), 0);
  res.json({ totalCompanies, completedVisits, totalIncome, totalExpense });
});

// File export
app.get('/api/reports/export/:file', (req, res) => {
  res.setHeader('Content-Type', 'text/plain');
  res.setHeader('Content-Disposition', `attachment; filename=\"${req.params.file}\"`);
  res.send('Mock report content');
});

app.listen(PORT, () => console.log(`Simple API running on http://localhost:${PORT}`));


