import jsonServer from 'json-server';
import fs from 'fs';
import path from 'path';
import url from 'url';

const __filename = url.fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const server = jsonServer.create();
const router = jsonServer.router(path.join(__dirname, 'db.json'));
const middlewares = jsonServer.defaults();

server.use(middlewares);
server.use(jsonServer.bodyParser);

// CORS
server.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// Simple auth mocks
server.post('/api/auth/register', (req, res) => {
  const { fullName, email, username, password } = req.body || {};
  if (!fullName || !email || !username || !password) {
    return res.status(400).json({ message: 'Eksik alanlar' });
  }
  const db = router.db; // lowdb instance
  const existing = db.get('users').find({ username }).value();
  if (existing) return res.status(400).json({ message: 'Kullanıcı zaten var' });
  const id = Date.now();
  db.get('users').push({ id, fullName, email, username, password }).write();
  return res.status(201).json({ id, fullName, email, username });
});

server.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const db = router.db;
  const user = db.get('users').find({ username, password }).value();
  if (!user) return res.status(401).json({ message: 'Geçersiz kimlik bilgileri' });
  const token = 'mock-token-' + user.id;
  return res.json({ token, user: { id: user.id, username: user.username, fullName: user.fullName } });
});

// Auth middleware (very light)
server.use((req, res, next) => {
  if (req.path.startsWith('/api') && !req.path.startsWith('/api/auth')) {
    // accept any Bearer token
    return next();
  }
  next();
});

// Me endpoints
server.get('/api/auth/me', (req, res) => {
  const db = router.db;
  const first = db.get('users').value()[0];
  res.json({ id: first.id, username: first.username, fullName: first.fullName, email: first.email, phone: first.phone });
});

server.post('/api/auth/change-password', (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!currentPassword || !newPassword) return res.status(400).json({ message: 'Eksik alan' });
  const db = router.db;
  const first = db.get('users').value()[0];
  if (first.password !== currentPassword) return res.status(400).json({ message: 'Mevcut şifre hatalı' });
  db.get('users').find({ id: first.id }).assign({ password: newPassword }).write();
  res.json({ success: true });
});

// Dashboard stats
server.get('/api/dashboard/stats', (req, res) => {
  const db = router.db;
  const companies = db.get('companies').value();
  const visits = db.get('visits').value();
  const totalIncome = visits.reduce((s, v) => s + (Number(v.incomeAmount) || 0), 0);
  const totalExpense = visits.reduce((s, v) => s + (Number(v.expenseAmount) || 0), 0);
  const completedVisits = visits.filter(v => v.status === 'completed').length;
  res.json({ totalCompanies: companies.length, completedVisits, totalIncome, totalExpense });
});

// File export mock
server.get('/api/reports/export/:fileName', (req, res) => {
  res.setHeader('Content-Type', 'text/plain');
  res.setHeader('Content-Disposition', `attachment; filename="${req.params.fileName}"`);
  res.send('Mock report content');
});

// Mount router with rewriter (no extra /api prefix to avoid double-prefix)
const routes = JSON.parse(fs.readFileSync(path.join(__dirname, 'routes.json')));
server.use(jsonServer.rewriter(routes));
server.use(router);

const PORT = process.env.PORT || 7000;
server.listen(PORT, () => {
  console.log(`Mock API running on http://localhost:${PORT}`);
});


